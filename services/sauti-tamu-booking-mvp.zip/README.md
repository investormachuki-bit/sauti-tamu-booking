# Sauti Tamu Booking

Mobile-first Next.js + Supabase MVP for Sauti Tamu Piano Center.

## Included

- Public free-trial booking for Piano or Acoustic Guitar
- Kenyan WhatsApp validation in `+2547XXXXXXXX`
- Available-slot selection
- Admin login
- Admin daily schedule
- Admin slot creation
- Booking status updates
- Supabase RPC booking transaction

## Setup

1. Copy `.env.local.example` to `.env.local`.
2. Add the Supabase publishable key.
3. Run `npm install`.
4. Run `npm run dev`.
5. Create an admin user in Supabase Authentication.
6. Open `/admin` and sign in.

The database migration has already been applied to project `clpjhxhwkmxlicagdtcw`.

## Next phase

Connect transactional email + WhatsApp providers to the booking event, then add the automated reminder/follow-up worker.
