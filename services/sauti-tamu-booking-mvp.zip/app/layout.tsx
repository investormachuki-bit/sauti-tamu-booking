import "./globals.css";

export const metadata = {
  title: "Sauti Tamu Piano Center | Free Trial Lesson",
  description: "Book your free Piano or Acoustic Guitar trial lesson at Sauti Tamu Piano Center.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
