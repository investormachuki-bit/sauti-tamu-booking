"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "../../lib/supabase";

type Instrument = "piano" | "guitar";

type Slot = {
  id: string;
  instrument: Instrument;
  starts_at: string;
  ends_at: string;
};

const centerAddress =
  "Junction Trade Center, 4th Floor, Room F401, Above Equity Bank Tearoom Branch, Nairobi CBD";

function formatDay(iso: string) {
  return new Intl.DateTimeFormat("en-KE", {
    timeZone: "Africa/Nairobi",
    weekday: "short",
    day: "numeric",
    month: "short",
  }).format(new Date(iso));
}

function formatTime(iso: string) {
  return new Intl.DateTimeFormat("en-KE", {
    timeZone: "Africa/Nairobi",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(iso));
}

export default function BookingPage() {
  const [instrument, setInstrument] = useState<Instrument | null>(null);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [form, setForm] = useState({ fullName: "", whatsapp: "", email: "" });
  const [booking, setBooking] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!instrument) return;
    setSelectedSlot(null);
    setLoadingSlots(true);
    setError("");

    supabase
      .from("lesson_slots")
      .select("id,instrument,starts_at,ends_at")
      .eq("instrument", instrument)
      .eq("is_available", true)
      .gt("starts_at", new Date().toISOString())
      .order("starts_at")
      .limit(50)
      .then(({ data, error }) => {
        if (error) setError(error.message);
        setSlots((data as Slot[]) || []);
        setLoadingSlots(false);
      });
  }, [instrument]);

  const groupedSlots = useMemo(() => {
    const map = new Map<string, Slot[]>();
    for (const slot of slots) {
      const key = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Africa/Nairobi",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(new Date(slot.starts_at));
      map.set(key, [...(map.get(key) || []), slot]);
    }
    return [...map.entries()];
  }, [slots]);

  async function submitBooking(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!selectedSlot || !instrument) {
      setError("Please select a trial time.");
      return;
    }

    const whatsapp = form.whatsapp.replace(/\s+/g, "");
    if (!/^\+2547\d{8}$/.test(whatsapp)) {
      setError("Enter your WhatsApp number as +2547XXXXXXXX.");
      return;
    }

    setBooking(true);

    const { error } = await supabase.rpc("book_free_trial", {
      p_full_name: form.fullName.trim(),
      p_whatsapp_number: whatsapp,
      p_email: form.email.trim().toLowerCase(),
      p_slot_id: selectedSlot.id,
      p_instrument: instrument,
    });

    if (error) {
      setError(error.message.replace(/^.*?:\s*/, ""));
      setBooking(false);
      return;
    }

    setSuccess(true);
    setBooking(false);
  }

  if (success) {
    return (
      <main className="page-shell">
        <section className="success-card">
          <div className="brand-mark">ST</div>
          <div className="success-icon">✓</div>
          <p className="eyebrow">BOOKING CONFIRMED</p>
          <h1>You&apos;re booked.</h1>
          <p className="lead">
            Your free {instrument === "piano" ? "Piano" : "Acoustic Guitar"} trial lesson
            has been reserved successfully.
          </p>
          <div className="confirmation">
            <strong>{formatDay(selectedSlot!.starts_at)}</strong>
            <span>{formatTime(selectedSlot!.starts_at)}</span>
            <small>{centerAddress}</small>
          </div>
          <p className="muted">
            We&apos;ll send your confirmation and reminders to your WhatsApp number and email.
          </p>
          <button className="gold-button" onClick={() => window.location.reload()}>
            Book another trial
          </button>
        </section>
      </main>
    );
  }

  return (
    <main className="page-shell">
      <nav className="topbar">
        <div className="brand">
          <div className="brand-mark small">ST</div>
          <div>
            <strong>Sauti Tamu</strong>
            <span>Piano Center</span>
          </div>
        </div>
        <a href="/admin" className="admin-link">Admin</a>
      </nav>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">SAUTI TAMU PIANO CENTER</p>
          <h1>Start your musical journey with a <em>free trial.</em></h1>
          <p className="lead">
            Choose Piano or Acoustic Guitar, pick a convenient time, and come experience your first lesson with us.
          </p>
        </div>

        <div className="booking-card">
          <div className="progress"><span className={instrument ? "active" : ""} /></div>

          <div className="step">
            <p className="step-label">01 — CHOOSE YOUR INSTRUMENT</p>
            <h2>What would you like to learn?</h2>

            <div className="instrument-grid">
              <button
                className={`instrument ${instrument === "piano" ? "selected" : ""}`}
                onClick={() => setInstrument("piano")}
              >
                <span className="instrument-icon">♬</span>
                <span><b>Piano</b><small>Free trial lesson</small></span>
              </button>
              <button
                className={`instrument ${instrument === "guitar" ? "selected" : ""}`}
                onClick={() => setInstrument("guitar")}
              >
                <span className="instrument-icon">♪</span>
                <span><b>Acoustic Guitar</b><small>Free trial lesson</small></span>
              </button>
            </div>
          </div>

          {instrument && (
            <div className="step">
              <p className="step-label">02 — CHOOSE A TIME</p>
              <h2>Pick your trial lesson</h2>

              {loadingSlots ? (
                <div className="empty">Loading available times…</div>
              ) : groupedSlots.length === 0 ? (
                <div className="empty">
                  No available trial times yet. Please check again shortly.
                </div>
              ) : (
                <div className="slot-days">
                  {groupedSlots.map(([day, daySlots]) => (
                    <div className="day-group" key={day}>
                      <div className="day-title">{formatDay(daySlots[0].starts_at)}</div>
                      <div className="slot-grid">
                        {daySlots.map((slot) => (
                          <button
                            key={slot.id}
                            className={`slot ${selectedSlot?.id === slot.id ? "selected" : ""}`}
                            onClick={() => setSelectedSlot(slot)}
                          >
                            {formatTime(slot.starts_at)}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {selectedSlot && (
            <form className="step form-step" onSubmit={submitBooking}>
              <p className="step-label">03 — YOUR DETAILS</p>
              <h2>Where should we send your confirmation?</h2>

              <label>
                Full name
                <input
                  required
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  placeholder="Your full name"
                />
              </label>

              <label>
                WhatsApp number
                <input
                  required
                  inputMode="tel"
                  value={form.whatsapp}
                  onChange={(e) => setForm({ ...form, whatsapp: e.target.value })}
                  placeholder="+2547XXXXXXXX"
                />
                <small>Use the number you actively use on WhatsApp.</small>
              </label>

              <label>
                Email address
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                />
              </label>

              {error && <div className="error">{error}</div>}

              <button className="gold-button full" disabled={booking}>
                {booking ? "Confirming your booking…" : "BOOK MY FREE TRIAL"}
              </button>

              <p className="privacy">
                By booking, you agree to receive booking confirmations and lesson reminders from Sauti Tamu.
              </p>
            </form>
          )}
        </div>
      </section>

      <footer>
        <span>© Sauti Tamu Piano Center</span>
        <span>{centerAddress}</span>
      </footer>
    </main>
  );
}
