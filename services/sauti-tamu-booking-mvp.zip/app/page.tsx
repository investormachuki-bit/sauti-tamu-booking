import BookingPage from "./booking/BookingPage";

export default function Home() {
  return <BookingPage />;
}
