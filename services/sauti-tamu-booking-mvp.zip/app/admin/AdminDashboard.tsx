"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

type Booking = {
  id: string;
  instrument: "piano" | "guitar";
  status: string;
  leads: { full_name: string; whatsapp_number: string; email: string } | null;
  lesson_slots: { starts_at: string; ends_at: string } | null;
};

function dateTime(iso?: string) {
  if (!iso) return "";
  return new Intl.DateTimeFormat("en-KE", {
    timeZone: "Africa/Nairobi",
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(iso));
}

export default function AdminDashboard() {
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [slot, setSlot] = useState({ instrument: "piano", date: "", time: "" });

  async function load() {
    const { data } = await supabase
      .from("bookings")
      .select("id,instrument,status,leads(full_name,whatsapp_number,email),lesson_slots(starts_at,ends_at)")
      .order("created_at", { ascending: false })
      .limit(100);
    setBookings((data as unknown as Booking[]) || []);
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) load();
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) load();
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setMessage(error.message);
    setLoading(false);
  }

  async function addSlot(e: React.FormEvent) {
    e.preventDefault();
    if (!slot.date || !slot.time) return;
    setMessage("");
    const starts = new Date(`${slot.date}T${slot.time}:00+03:00`);
    const ends = new Date(starts.getTime() + 60 * 60 * 1000);

    const { error } = await supabase.from("lesson_slots").insert({
      instrument: slot.instrument,
      starts_at: starts.toISOString(),
      ends_at: ends.toISOString(),
      is_available: true,
    });

    if (error) setMessage(error.message);
    else {
      setMessage("Trial slot created.");
      setSlot({ ...slot, date: "", time: "" });
    }
  }

  async function updateStatus(id: string, status: string) {
    const { error } = await supabase.from("bookings").update({
      status,
      ...(status === "completed" ? { attended_at: new Date().toISOString(), completed_at: new Date().toISOString() } : {}),
      ...(status === "no_show" ? { attended_at: null } : {}),
    }).eq("id", id);
    if (error) setMessage(error.message);
    else load();
  }

  if (!session) {
    return (
      <main className="admin-shell">
        <div className="login-card">
          <div className="brand-mark">ST</div>
          <p className="eyebrow">ADMIN</p>
          <h1>Sauti Tamu Dashboard</h1>
          <p className="muted">Sign in to manage trial bookings and availability.</p>
          <form onSubmit={login}>
            <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
            <label>Password<input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label>
            {message && <div className="error">{message}</div>}
            <button className="gold-button full" disabled={loading}>{loading ? "Signing in…" : "SIGN IN"}</button>
          </form>
        </div>
      </main>
    );
  }

  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Nairobi" }).format(new Date());
  const todayBookings = bookings.filter((b) => {
    const d = b.lesson_slots?.starts_at;
    return d && new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Nairobi" }).format(new Date(d)) === today;
  });

  return (
    <main className="admin-shell">
      <nav className="admin-nav">
        <div className="brand"><div className="brand-mark small">ST</div><div><strong>Sauti Tamu</strong><span>Admin</span></div></div>
        <div className="nav-actions"><a href="/">Public booking</a><button onClick={() => supabase.auth.signOut()}>Sign out</button></div>
      </nav>

      <section className="admin-content">
        <div className="admin-heading">
          <div><p className="eyebrow">ADMIN DASHBOARD</p><h1>What&apos;s happening today?</h1><p className="muted">{todayBookings.length} trial lesson{todayBookings.length === 1 ? "" : "s"} scheduled today.</p></div>
          <div className="date-chip">{new Intl.DateTimeFormat("en-KE", { timeZone: "Africa/Nairobi", dateStyle: "full" }).format(new Date())}</div>
        </div>

        <div className="stat-grid">
          <div className="stat"><span>Today</span><b>{todayBookings.length}</b><small>Trial lessons</small></div>
          <div className="stat"><span>Upcoming</span><b>{bookings.length}</b><small>Loaded bookings</small></div>
          <div className="stat"><span>Confirmed</span><b>{bookings.filter(b => b.status === "confirmed").length}</b><small>Awaiting attendance</small></div>
          <div className="stat"><span>Completed</span><b>{bookings.filter(b => b.status === "completed").length}</b><small>Trial lessons</small></div>
        </div>

        <div className="admin-grid">
          <section className="panel">
            <div className="panel-title"><div><p className="eyebrow">TODAY</p><h2>Trial schedule</h2></div><button onClick={load}>Refresh</button></div>
            {todayBookings.length === 0 ? <div className="empty">No trials booked for today.</div> : todayBookings.map((b) => (
              <div className="booking-row" key={b.id}>
                <div className="time">{dateTime(b.lesson_slots?.starts_at).split(", ").slice(-1)[0]}</div>
                <div className="booking-person"><b>{b.leads?.full_name}</b><span>{b.instrument === "piano" ? "🎹 Piano" : "🎸 Acoustic Guitar"} · {b.leads?.whatsapp_number}</span></div>
                <select value={b.status} onChange={(e) => updateStatus(b.id, e.target.value)}>
                  <option value="confirmed">Confirmed</option><option value="completed">Completed</option><option value="no_show">No show</option><option value="cancelled">Cancelled</option>
                </select>
              </div>
            ))}
          </section>

          <section className="panel">
            <div className="panel-title"><div><p className="eyebrow">AVAILABILITY</p><h2>Add trial slot</h2></div></div>
            <form onSubmit={addSlot}>
              <label>Instrument<select value={slot.instrument} onChange={(e) => setSlot({...slot, instrument: e.target.value})}><option value="piano">Piano</option><option value="guitar">Acoustic Guitar</option></select></label>
              <label>Date<input type="date" value={slot.date} onChange={(e) => setSlot({...slot, date: e.target.value})} required /></label>
              <label>Start time<input type="time" value={slot.time} onChange={(e) => setSlot({...slot, time: e.target.value})} required /></label>
              {message && <div className="notice">{message}</div>}
              <button className="gold-button full">ADD 1-HOUR TRIAL SLOT</button>
            </form>
          </section>
        </div>

        <section className="panel">
          <div className="panel-title"><div><p className="eyebrow">BOOKINGS</p><h2>Recent bookings</h2></div></div>
          <div className="table-wrap"><table><thead><tr><th>Student</th><th>Instrument</th><th>Trial</th><th>Status</th><th>Contact</th></tr></thead><tbody>
            {bookings.map((b) => <tr key={b.id}><td><b>{b.leads?.full_name}</b><small>{b.leads?.email}</small></td><td>{b.instrument === "piano" ? "🎹 Piano" : "🎸 Guitar"}</td><td>{dateTime(b.lesson_slots?.starts_at)}</td><td><span className={`status ${b.status}`}>{b.status.replace("_"," ")}</span></td><td>{b.leads?.whatsapp_number}</td></tr>)}
          </tbody></table></div>
        </section>
      </section>
    </main>
  );
}
